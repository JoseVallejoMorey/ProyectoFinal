package classes;

public class Navegacion {

	public String destino;

	public Navegacion(String destino){
		this.destino = destino;
	}

	
	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}
	
	
	
	
}
